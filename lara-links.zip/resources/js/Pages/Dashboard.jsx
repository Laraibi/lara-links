import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout";
import { Head } from "@inertiajs/react";
import CreateLinkForm from "@/Components/CreateLinkForm";
import DashboardLinks from "@/Components/DashboardLinks";

export default function Dashboard() {
    return (
        <AuthenticatedLayout
            header={
                <h2 className="text-xl font-semibold leading-tight text-gray-800">
                    Dashboard
                </h2>
            }
        >
            <Head title="Dashboard" />

            <div className="py-12">
                <div className="mx-auto max-w-7xl sm:px-6 lg:px-8">
                    <CreateLinkForm />
                </div>
            </div>
            <div className="container mx-auto">
                <DashboardLinks />
            </div>
        </AuthenticatedLayout>
    );
}
